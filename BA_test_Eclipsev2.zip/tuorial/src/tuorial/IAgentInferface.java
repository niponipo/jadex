package tuorial;

import jadex.commons.future.IFuture;

public interface IAgentInferface
{
	void message(String sender, String text);
	void test();
	
	IFuture<String> getString();
}
